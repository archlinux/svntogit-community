#ifndef _CARD_TYPE_H
#define _CARD_TYPE_H 1

enum class CardType {
	LIVE_CARD,
	FAKE_CAPTURE,
	FFMPEG_INPUT,
	CEF_INPUT,
};

#endif  // !defined(_CARD_TYPE_H)
